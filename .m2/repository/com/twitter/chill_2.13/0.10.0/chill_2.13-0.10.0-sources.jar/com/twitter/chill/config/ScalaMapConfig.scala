/*
Copyright 2012 Twitter, Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 */

package com.twitter.chill.config

object ScalaMapConfig {
  def apply(m: Map[String, String]): ScalaMapConfig = new ScalaMapConfig(m)
  def empty: ScalaMapConfig = new ScalaMapConfig(Map.empty)
}

/**
 * A simple config backed by an immutable Map
 */
class ScalaMapConfig(in: Map[String, String]) extends Config {
  private var conf = in

  def toMap: Map[String, String] = conf

  def get(k: String): String = conf.getOrElse(k, null)
  def set(k: String, v: String): Unit =
    if (null == v) {
      conf -= k
    } else {
      conf += k -> v
    }
}
