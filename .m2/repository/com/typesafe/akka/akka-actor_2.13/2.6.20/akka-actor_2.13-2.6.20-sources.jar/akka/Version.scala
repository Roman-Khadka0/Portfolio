package akka

object Version {
  val current: String = "2.6.20"
}
