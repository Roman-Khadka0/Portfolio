/*
 * Copyright (c) 2015, 2018 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0, which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * This Source Code may also be made available under the following Secondary
 * Licenses when the conditions for such availability set forth in the
 * Eclipse Public License v. 2.0 are satisfied: GNU General Public License,
 * version 2 with the GNU Classpath Exception, which is available at
 * https://www.gnu.org/software/classpath/license.html.
 *
 * SPDX-License-Identifier: EPL-2.0 OR GPL-2.0 WITH Classpath-exception-2.0
 */

package org.glassfish.jersey.server.internal.routing;

import org.glassfish.jersey.server.model.ResourceModel;

/**
 * A pair of sub-resource locator model and a corresponding model router.
 *
 * @author Michal Gajdos
 */
final class LocatorRouting {

    /**
     * Sub-resource locator model.
     */
    final ResourceModel locator;

    /**
     * Sub-resource locator router.
     */
    final Router router;

    /**
     * Create a new instance.
     *
     * @param locator  sub-resource locator model.
     * @param router router that is needed to execute the {@code model}.
     */
    LocatorRouting(final ResourceModel locator, final Router router) {
        this.locator = locator;
        this.router = router;
    }
}
